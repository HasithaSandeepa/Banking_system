<?php 

if(!isset($_COOKIE['UID'])) {
  
    header("location: user_login.php");

}

?>